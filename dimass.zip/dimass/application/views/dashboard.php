<h1>halaman dashboard</h1>
<a href="<?= base_url('loginpemilih') ?>">login</a>