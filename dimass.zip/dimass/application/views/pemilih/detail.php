<div class="container">
<div class="card bg-light mt-3">
    <div class="card-header">
        <div>Detail Kandidat <?= $kandidat['id_kandidat'] ?></div>
    </div>
    <div class="container">

        <div class="card-body">
            <div class="card mb-3">
                <div class="row">
                    <div class="col-md-4">
                        <img src="<?= base_url('assets/img/'); ?><?= $kandidat['image']; ?>" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <button class="btn-secondary mb-3 d-flex shadow col-12 mx-auto rounded justify-content-left mt-4" style="height: 5vh; align-items: center;" disabled>NAMA KETUA OSIS : <?= $kandidat['nama_ketos'] ?></button>
                            <button class="btn-secondary mb-3 d-flex shadow col-12 mx-auto rounded justify-content-left" style="height: 5vh; align-items: center;" disabled>NAMA WAKIL KETUA OSIS : <?= $kandidat['nama_waketos'] ?></button>
                            <button class="btn-secondary mb-3 d-flex shadow col-12 mx-auto rounded justify-content-left" style="height: 5vh; align-items: center;" disabled>VISI : <?= $kandidat['visi'] ?></button>
                            <button class="btn-secondary mb-3 d-flex shadow col-12 mx-auto rounded justify-content-left" style="height: 5vh; align-items: center;" disabled>MISI : <?= $kandidat['misi'] ?></button>
                        </div>
                    </div>
                </div>
            </div>
            <a href="<?= base_url('kandidat'); ?>" class="btn btn-danger">Kembali</a>
        </div>
    </div>
</div>
</div>
