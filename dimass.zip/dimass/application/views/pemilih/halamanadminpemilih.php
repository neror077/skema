<div class="container mt-5">
<div class="d-grid gap-2 d-md-block">
    <a href="<?= base_url('kandidat') ?>" class="btn btn-primary">Kandidat</a>
    <a href="<?= base_url('admin') ?>" class="btn btn-primary">Admin</a>
    <a href="<?= base_url('adminpemilih') ?>" class="btn btn-primary">Pemilih</a>
    <a href=" <?= base_url('hasil') ?>" class="btn btn-primary">Hasil</a>
</div>
<div class="card mt-3">
  <div class="card-header">
  <div class="d-flex justify-content-between">
  <a href="<?= base_url('adminpemilih/tambah') ?>" class="btn btn-success my-2">Tambah</a>
    </div>
  </div>
<div class="carousel mt-3 d-flex justify-content-center">
    <table class="table table-bordered table-striped mx-3">
        <thead class="table-primary">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Username</th>
                <th scope="col">Nama</th>
                <th scope="col">Password</th>
                <th scope="col">NISN</th>
                <th scope="col">Alamat</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach($pemilih as $pml) : ?>
            <tr>
                <th scope="row"><?= $no++ ?></th>
                <td><?= $pml['username'] ?></td>
                <td><?= $pml['nama'] ?></td>
                <td><?= $pml['password'] ?></td>
                <td><?= $pml['NISN'] ?></td>
                <td><?= $pml['alamat'] ?></td>
                <td><a href="<?= base_url('adminpemilih/edit/') ?><?= $pml['id_pemilih'] ?>" class="btn btn-warning">Edit</a>
                <a href="<?= base_url('adminpemilih/hapus/') ?><?= $pml['id_pemilih'] ?>" class="btn btn-danger" onclick="return confirm('yakin ingin menghapus <?= $pml['username'] ?> ini?') ">Hapus</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div></div>