<div class="container mt-5">
<div class="d-grid gap-2 d-md-block">
    <a href="<?= base_url('kandidat') ?>" class="btn btn-primary">Kandidat</a>
    <a href="<?= base_url('admin') ?>" class="btn btn-primary">Admin</a>
    <a href="<?= base_url('adminpemilih') ?>" class="btn btn-primary">Pemilih</a>
    <a href=" <?= base_url('hasil') ?>" class="btn btn-primary">Hasil</a>
</div>
<div class="card mt-3">
  <div class="card-header">
  <div class="d-flex justify-content-between">
  <a href="<?= base_url('admin/tambah') ?>" class="btn btn-success my-2">Tambah</a>
    </div>
  </div>
<div class="carousel mt-3 d-flex justify-content-center">
    <table class="table table-bordered table-striped mx-3">
        <thead class="table-primary">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Email</th>
                <th scope="col">Password</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach($user as $usr) : ?>
            <tr>
                <th scope="row"><?= $no++ ?></th>
                <td><?= $usr['username'] ?></td>
                <td><?= $usr['email'] ?></td>
                <td><?= $usr['password'] ?></td>
                <td><a href="<?= base_url('admin/edit/') ?><?= $usr['id_user'] ?>" class="btn btn-warning">Edit</a>
                <a href="<?= base_url('admin/hapus/') ?><?= $usr['id_user'] ?>" class="btn btn-danger" onclick="return confirm('yakin ingin menghapus <?= $usr['username'] ?> ini?') ">Hapus</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div></div></div>